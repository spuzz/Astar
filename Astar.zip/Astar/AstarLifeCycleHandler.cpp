#include "stdafx.h"
#include "AstarLifeCycleHandler.h"


AstarLifeCycleHandler::AstarLifeCycleHandler()
{

	g_done = false;
}

void AstarLifeCycleHandler::waitOnPath()
{

}

AstarLifeCycleHandler::~AstarLifeCycleHandler()
{
}
